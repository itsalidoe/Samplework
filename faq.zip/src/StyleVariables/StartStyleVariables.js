 export const txt_3789_txt_part_0_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_1_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_2_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_3_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_4_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_5_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_6_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_7_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_8_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_9_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_10_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_11_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_12_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_13_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_14_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_15_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_16_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_17_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_18_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_19_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_20_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_21_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_22_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_23_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_24_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_25_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_26_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_27_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_28_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_29_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_30_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_31_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_32_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_33_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_34_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_35_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_36_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_3789_txt_part_37_SketchStyle = {"opacity":1,"letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(82,95,125,1)","font-family":"ArialMT, 'Arial', sans-serif","font-size":"14px"};

 export const txt_4313_SketchStyle = {"opacity":1,"background":"transparent","letter-spacing":"normal","text-align":"justify","line-height":"inherit","color":"rgba(255,255,255,1)","font-family":"Arial-BoldMT, 'Arial', sans-serif","font-size":"25px"};

